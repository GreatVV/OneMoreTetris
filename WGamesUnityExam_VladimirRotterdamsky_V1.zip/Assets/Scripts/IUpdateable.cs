﻿public interface IUpdateable
{
    void Tick();
}