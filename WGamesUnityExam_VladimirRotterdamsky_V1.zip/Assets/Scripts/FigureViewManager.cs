﻿using System.Collections.Generic;
using UnityEngine;

public class FigureViewManager : IUpdateable
{
    private readonly Config _config;
    public List<FigureView> FigureViews = new List<FigureView>();

    public int PixelPerUnit
    {
        get { return _config.PixelPerUnit; }    
    }

    public FigureViewManager(Config config)
    {
        _config = config;
    }
	
    public void AddFigure(FigureView figureView)
    {
        FigureViews.Add(figureView);
    }

    public void Tick()
    {
        foreach (var figureView in FigureViews)
        {
            figureView.Tick();

            var figure = figureView.FigureDesc;
            var rotationSet = figure.RotationSets[figure.CurrentSet];
            for (var index = 0; index < figure.Blocks.Length; index++)
            {
                var block = figure.Blocks[index];
                
                if (!block.IsDestroyed)
                {
                    figureView.BlockViews[index].transform.localPosition = rotationSet[index] *PixelPerUnit ;
                }
            }
            figureView.Transform.anchoredPosition = new Vector3(figure.X * PixelPerUnit, figure.Y * PixelPerUnit);
        }
    }
}