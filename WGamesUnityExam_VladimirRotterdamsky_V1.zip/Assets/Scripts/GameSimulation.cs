﻿using System.Linq;
using UnityEngine.Experimental.Rendering;

public class GameSimulation : IUpdateable
{
    private readonly Config _config;
    private readonly GameState _gameState;
    private readonly FigureControl _control;
    private readonly IFigureFactory _figureFactory;
    private readonly FigureViewManager _figureViewManager;

    public bool IsGameOver;

    public GameSimulation(Config config, IFigureFactory figureFactory, FigureViewManager figureViewManager, GameState gameState, FigureControl control)
    {
        _config = config;
        _figureFactory = figureFactory;
        _figureViewManager = figureViewManager;
        _gameState = gameState;
        _control = control;
    }

    public void Tick()
    {
        if (_control.CurrentFigure == null)
        {
            var currentFigureDesc = _figureFactory.NewFigureDescription;
            var currentFigure = new Figure(currentFigureDesc);
            
            if (!_gameState.CanMoveTo(currentFigure, (int) _config.SpawnPosition.x, (int) _config.SpawnPosition.y))
            {
                IsGameOver = true;
            }
            else
            {
                var figureView = _figureFactory.SpawnFigure(currentFigureDesc);
                figureView.FigureDesc = currentFigure;
                currentFigure.RotationSets = currentFigureDesc.RotationSets;
                
                _figureViewManager.AddFigure(figureView);
                
                _gameState.MoveTo(currentFigure, (int) _config.SpawnPosition.x, (int) _config.SpawnPosition.y);

                _control.CurrentFigure = currentFigure;
            }
        }
    }
}